---
title: "Leçon 1 - Présentations"
date: "2025-06-12"
---

Bienvenue à la première leçon de portugais ! Dans cette leçon, vous allez apprendre à vous présenter.

**Exercice** : Comment dites-vous "Je m'appelle..." ?
