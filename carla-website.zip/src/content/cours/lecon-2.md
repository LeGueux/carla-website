---
title: "Leçon 2 - Les salutations"
date: "2025-06-12"
---

Dans cette leçon, vous apprendrez à dire bonjour, au revoir et à saluer les gens dans différentes situations.

**Exercice** : Quelle est la différence entre "Olá" et "Bom dia" ?
