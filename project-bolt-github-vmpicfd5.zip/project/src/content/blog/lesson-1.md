---
title: "Introduction to Portuguese"
date: "2025-06-12"
description: "Basic greetings and introductions"
---

Welcome to your first Portuguese lesson! Let's start with simple greetings.
