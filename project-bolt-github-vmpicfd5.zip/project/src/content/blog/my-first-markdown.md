---
layout: ../../layouts/BlogLayout.astro
title: "My First Markdown Post"
date: "2025-06-13"
description: "Markdown support in Astro is amazing!"
---

Welcome to the blog post written in Markdown!

- Easy to write
- Easy to read
- Looks great with Tailwind’s `prose` classes!
